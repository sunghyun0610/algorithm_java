package my.library;

public interface Borrowable {
     void borrow(String memberId, Library library);
}
